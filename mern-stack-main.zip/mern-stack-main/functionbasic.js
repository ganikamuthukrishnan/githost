//functions==>
    //parameterized
    //non parameterized
    //  -------------------------------------
    //non paramaterized + without   return
    // function apple()
    // {
    //     console.log("apple")

    // }
    // apple()
    // // -------------------------------------
       //non paramaterized + with return
    //    function orange()
    //    {
    //            return "orange";
    //    }
    //    //let a=orange();console.log(a);
    //    console.log(orange());
//------------------------------------------------
// parameterized+ without return
// function apple(a,b)
// {
//     console.log(a+b)
// }
// apple(10,20);
//------------------------------------------------
// parameterized+ with return
// function apple(a,b)
// {
    
//     return a+b;
// }
// console.log(apple(10,20));
//------------------------------------------------
//arrow functiion(single line function)
// let apple=()=>console.log("apple")
 
// apple();
//-------------------
// let orange=()=>"apple";
 
// console.log(orange());
//--------------------------------
// //arrow functiion(multi line function)
// let appl=()=>
// {
//     console.log("apple");
//     console.log("apple");
//     console.log("apple");
// }
// appl();
//-----------------------
// let banana =()=>
//     {
//         console.log("apple");
//         return 3+3;
//     } 
// banana();
//----------------------------
// let banana =()=>
//     {
//         console.log("apple");
//         return 3+3;
//     } 
// console.log(banana());
//--------------------------------------------------
// let add=(a,b)=>
// {
// return a+b;
// }
// console.log(add(1,2));
