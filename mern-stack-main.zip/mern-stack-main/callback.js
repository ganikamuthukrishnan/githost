//callback
//function as a parameter in  anoother function
                // function dora()
                // {
                //     console.log("buji")
                // }
                // function tom()
                // {
                //     console.log("jerry")
                // }
                // dora()
                // tom()



                // function dora() {
                //     setTimeout=(()=>{
                //     console.log("buji")},2000);
                // }
                // function tom() {
                //     console.log("jerry")
                // }
                // dora()
                // tom()

//-------------------------------------------


// function dora(callback) {
//     setTimeout(() => {
//         console.log("buji");
//         callback(); // Call the callback function
//     }, 2000);
// }
// function tom() {
//     console.log("jerry");
// }

// dora(tom);
