// function processing(callback, filename)
// {
//     console.log(`file ${filename} is  processing`);
//     callback();
// }
// function downloading(callback, filename)
// {
//     console.log(`file ${filename} is  downloading`);
//     callback();
// }
// const filename="abc";
// processing(()=>{
//     downloading(()=>{
//         console.log("download complete");
//     },filename);
    
// },filename);
